function List(params) {
    return (
        <div className="" id="liste">
            <input type="text" placeholder="Rechercher" />
            <select name="categ">
                    <option value="Alimentation">Alimentation</option>
                    <option value="Revenue">Revenue</option>
                    <option value="Divertissement">Divertissement</option>
                    <option value="Sante">Santé</option>
            </select>
            <select name="" id="">
                <option value="All">Tous</option>
            </select>
            <select name="filtre" id=""></select>
            <div></div>
        </div>
    );
}

export default List;

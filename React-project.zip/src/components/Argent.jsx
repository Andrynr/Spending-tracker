function Argent({ titre, icon, valeur}) {
    return (
        <div className="card">
            <div className="card-body">
                <p className="card-title"><span>{ icon }</span><span>{ titre }</span></p>
                <p>{ valeur }</p>
            </div>
        </div>
    );
}

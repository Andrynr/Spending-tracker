function Graph() {
    return (
        <div className="card">
            <div className="card-body">
                <h5 className="card-title"></h5>
                <div></div>
            </div>
        </div>
    );
}

export default Graph;

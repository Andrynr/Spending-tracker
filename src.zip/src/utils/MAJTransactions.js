/**
 * Supprime une transactions par Date
 *
 * @param {Array} transactions
 * @param {Date} aSupprimer
 * @returns
 */

export const suprTransaction = (transactions, aSupprimer) => {
  return transactions.filter((item) => item.date !== aSupprimer);
};

export const modifTransaction = (transactions, aModifier) => {
  return transactions.map((item) =>
    item.date === aModifier.date
      ? {
          ...item,
          libelle: aModifier.libelle,
          montant: aModifier.montant,
          categorie: aModifier.categorie,
        }
      : item
  );
};

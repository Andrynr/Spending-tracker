/**
 *
 * @param {object} newTransac - Nouvelle transaction à effectuer
 * @param {Array} argents - Tableau : Solde, Revenue, Dépense
 * @returns
 */

export const MAJArgents = ({ newTransac, argents }) => {
  let { solde, revenue, depense } = argents;

  switch (newTransac.type) {
    case "Solde":
      solde = newTransac.montant;
      break;
    case "Revenue":
      solde += newTransac.montant;
      revenue += newTransac.montant;
      break;
    case "Dépense":
      solde -= newTransac.montant;
      depense += newTransac.montant;
      break;
  }

  return { solde, revenue, depense };
};

export const modifArgents = (argents, anciTransac, nouvTransac) => {
  const tempTransac = {
    montant: -anciTransac.montant,
    type: anciTransac.type,
  };
  // On déduit le montant de l'argent d'abord
  const tempArgents = MAJArgents({ newTransac: tempTransac, argents });

  return MAJArgents({ newTransac: nouvTransac, argents: tempArgents });
};

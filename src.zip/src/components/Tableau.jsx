import { Form } from "react-bootstrap";
import Table from "react-bootstrap/Table";
import "../assets/css/List.css";
import useForm from "../hooks/useForm";
import { categorieList } from "../utils/Categorie";
import { filtrer } from "../utils/Filtre";
import TListe from "./TListe";
import { getMonth } from "../utils/dateFormat";

function Tableau({ transactions, dates, modifTransactions }) {
  // Déclaration des states pour le filtre
  const { values: filtres, handleChange } = useForm({
    date: new Date().toISOString().slice(0, 7),
    type: "",
    categorie: "",
    recherche: "",
  });

  // Appliquer les filtres
  const filtredTransactions = filtrer(
    transactions,
    filtres.date,
    filtres.type,
    filtres.categorie,
    filtres.recherche
  );
  filtredTransactions.reverse(); // Récente d'abord

  const categories = categorieList(filtres.type); // Catégories selon la type de transaction

  return (
    <>
      <h2 className="text-lg text-start fw-semibold">Liste des transactions</h2>
      <div className=" d-flex justify-content-between pt-3" id="liste">
        <Form.Control
          type="text"
          placeholder="Rechercher"
          value={filtres.recherche}
          name="recherche"
          onChange={handleChange}
        />
        <Form.Select
          value={filtres.categorie}
          onChange={handleChange}
          name="categorie"
        >
          <option value="All">Tout</option>
          {categories.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </Form.Select>
        <Form.Select
          value={filtres.type}
          onChange={handleChange}
          name="type"
          id="type"
        >
          <option value="All">Tous</option>
          <option value="Revenue">Revenue</option>
          <option value="Dépense">Dépense</option>
        </Form.Select>
        <Form.Select
          className="text-capitalize"
          value={filtres.date}
          onChange={handleChange}
          name="date"
          id="date"
        >
          {dates.map((date) => (
            <option key={date} value={date}>
              {getMonth(date)}
            </option>
          ))}
        </Form.Select>
      </div>

      <Table className="mt-2 table-responsive table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Date</th>
            <th scope="col">Libellé</th>
            <th scope="col">Catégorie</th>
            <th scope="col">Montant</th>
          </tr>
        </thead>
        <tbody>
          <TListe
            filtredTransactions={filtredTransactions}
            modifTransactions={modifTransactions}
          />
        </tbody>
      </Table>
      <footer className="sticky-bottom">
        <span
          className="px-2 shadow-lg w-auto rounded-pill"
          style={{ cursor: "default" }}
        >
          <span>{filtredTransactions.length}</span> transactions
        </span>
      </footer>
    </>
  );
}

export default Tableau;

import { format } from "../utils/format";
import "../assets/css/TListe.css";
import TransacModal from "./TransacModal";
import { useState } from "react";
/**
 *Une ligne de tableau
 *
 * @param {Object} filtredTransactions - Tableau de transactions
 */

function TListe({ filtredTransactions, modifTransactions }) {
  const [afficher, setAfficher] = useState(false);
  const [ancienneTransaction, setAncienneTransaction] = useState({});

  const afficheModal = ({ transaction }) => {
    setAncienneTransaction(transaction);
    setAfficher(true);
  };
  return (
    <>
      {filtredTransactions && filtredTransactions.length > 0 ? (
        filtredTransactions?.map((transaction, i) => (
          <tr key={i}>
            <td>{++i}</td>
            <td>{transaction.date.toLocaleString()}</td>
            <td className="overflow-auto">{transaction.libelle}</td>
            <td>{transaction.categorie}</td>
            <td>
              {format(
                transaction.type === "Dépense"
                  ? -transaction.montant
                  : transaction.montant
              )}
              <span className="ms-1 d-none">
                <button
                  className="btn btn-sm mx-0"
                  type="button"
                  onClick={() => afficheModal({ transaction })}
                >
                  🖉
                </button>
                <button
                  className="btn btn-sm mx-0"
                  type="button"
                  onClick={() =>
                    modifTransactions("supprimer", transaction.date)
                  }
                >
                  🗑
                </button>
              </span>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={5}>
            <p className="text-center fs-4">Aucune transaction trouvée.</p>
          </td>
        </tr>
      )}
      <TransacModal
        modifTransactions={modifTransactions}
        ancienneTransaction={ancienneTransaction}
        mShow={afficher}
        transType="Modification"
        fermer={() => setAfficher(false)}
      />
    </>
  );
}
export default TListe;

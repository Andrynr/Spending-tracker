import { createContext } from "react";

export const transactionsContext = createContext([]);
